from jinja2 import Template
import json
import pdfkit

template_filename = "htmltemplatepdf.j2"
json_file = "sortSevLambda.json"
output_file = 'output.html'

def process_template():
    with open(template_filename, 'r') as tf:
        with open(json_file, 'r') as jf:
            data = json.load(jf)
#            print(type(data))
            template = Template(tf.read())
#            print(template.render())
            finalData = template.render(aggregatorRules = data['AggregatorRules'])
#            print('Rendered', finalData)
            with open(output_file,'w') as of:
                of.write(finalData)
process_template()

options = {
    'page-size': 'Letter',
    'margin-top': '0.50in',
    'margin-right': '0.50in',
    'margin-bottom': '0.50in',
    'margin-left': '0.50in',
    'encoding': "UTF-8",
    'custom-header': [
        ('Accept-Encoding', 'gzip')
    ],
    'no-outline': None
}
pdfkit.from_file('output.html', 'convertedpdf1.pdf', options=options)
#pdfkit.from_file('htmlfileconvert.html', 'convertedpdf.pdf')
